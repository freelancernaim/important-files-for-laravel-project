Laravel\Socialite\Two\User Object
(
    [token] => ya29.GlwzBR3CQXTe3GbPz-J7jDPpSJONmRxz45hvZGNcZqL79loyyzV4XvXVlu3gk3rNTPCjM_RT-JEPiNCf1n5bmd00aLq3cAHzHlvRpmN52qPXytwi6qfKzjgyapQY6w
    [refreshToken] => 
    [expiresIn] => 3599
    [id] => 102189318212129062213
    [nickname] => 
    [name] => Md. Shohan Hossain
    [email] => shohan.cit.bd@gmail.com
    [avatar] => https://lh4.googleusercontent.com/-uPa83Tm9tn8/AAAAAAAAAAI/AAAAAAAAAAc/tLYHQtUqJOU/photo.jpg?sz=50
    [user] => Array
        (
            [kind] => plus#person
            [etag] => "ucaTEV-ZanNH5M3SCxYRM0QRw2Y/ycYS_iw1BkP-TklzoBxCtU7SbOI"
            [emails] => Array
                (
                    [0] => Array
                        (
                            [value] => shohan.cit.bd@gmail.com
                            [type] => account
                        )

                )

            [objectType] => person
            [id] => 102189318212129062213
            [displayName] => Md. Shohan Hossain
            [name] => Array
                (
                    [familyName] => Hossain
                    [givenName] => Md. Shohan
                )

            [image] => Array
                (
                    [url] => https://lh4.googleusercontent.com/-uPa83Tm9tn8/AAAAAAAAAAI/AAAAAAAAAAc/tLYHQtUqJOU/photo.jpg?sz=50
                    [isDefault] => 
                )

            [isPlusUser] => 
            [language] => en
            [verified] => 
        )

    [avatar_original] => https://lh4.googleusercontent.com/-uPa83Tm9tn8/AAAAAAAAAAI/AAAAAAAAAAc/tLYHQtUqJOU/photo.jpg
)