#Link to MySqli Functions
https://www.w3schools.com/php/php_ref_mysqli.asp